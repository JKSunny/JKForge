function render_pipeline_step( step_id, step ) 
{
    let details_html = ""

    if (step.type === "demo_queue")
        details_html = render_demo_queue_details(step)

    let icon = "fa-circle"

    if (step.status === "finished")
        icon = "fa-check"

    else if (step.status === "running")
        icon = "fa-spinner fa-spin"

    else if (step.status === "failed")
        icon = "fa-xmark"

    return `
        <div class="pipeline-step pipeline-${step.status}">
            <div class="pipeline-step-header">
                <i class="fa-solid ${icon}"></i>

                <span class="pipeline-step-name">
                    ${step_id}
                </span>

                ${
                    step.started
                    ? `
                        <span class="pipeline-step-duration">
                            ${format_run_duration(
                                run_duration({
                                    started: step.started,
                                    ended: step.ended
                                })
                            )}
                        </span>
                    `
                    : ""
                }
            </div>

            ${details_html}
        </div>
    `
}

function render_run_pipeline() 
{
    const env = current_environments.find(e => e.id === selectedRunEnvironmentId)
    const run = env?.runs?.find(r => r.id === selectedRunId)

    if ( !env || !run ) 
        return

    const pipeline = run.pipeline

    if ( !pipeline )
        return ""

    runPipeline = document.querySelector('#runPipeline')

    let html = ``

    for (const [step_id, step] of Object.entries(pipeline.steps || {})) 
    {
        html += render_pipeline_step(step_id, step)
    }

    runPipeline.innerHTML = html
}